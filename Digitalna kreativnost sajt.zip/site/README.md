# Digitalna kreativnost — sajt

Statičan sajt, spreman za GitHub Pages.

## Objavljivanje
1. Napravi repozitorijum na GitHubu (npr. `digitalna-kreativnost`).
2. Prebaci sadržaj ovog foldera u koren repozitorijuma (`index.html`, `support.js`, `assets/`).
3. Settings → Pages → Source: `Deploy from a branch`, Branch: `main` / `root` → Save.
4. Sajt je za par minuta na `https://<korisnik>.github.io/<repo>/`.

## Struktura
- `index.html` — cela strana (sadržaj, stilovi, logika)
- `support.js` — runtime potreban za prikaz
- `assets/` — logo i slike radova

## Napomene
- Forma za upit trenutno ne šalje mejl; za pravo slanje priključiti servis (Formspree, Netlify Forms) ili mali backend.
- Fontovi se učitavaju sa Google Fonts (potreban internet).
